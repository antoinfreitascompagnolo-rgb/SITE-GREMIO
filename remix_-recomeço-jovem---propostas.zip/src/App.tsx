/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, ChangeEvent, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { subscribeToSettings, updateLogo } from "./lib/firebase";
import { 
  Sprout, 
  Leaf, 
  Droplets, 
  Zap, 
  Recycle, 
  Trophy, 
  Users, 
  ArrowRight,
  Flame,
  Globe,
  Heart,
  Menu,
  X,
  Settings,
  Image as ImageIcon,
  Upload,
  RefreshCcw,
  Lock,
  Key
} from "lucide-react";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

type TabId = "ambiente" | "esportes" | "social" | "editar";

function PhoenixLogo({ className, customUrl }: { className?: string; customUrl?: string }) {
  if (customUrl) {
    return (
      <div className={`${className} flex items-center justify-center overflow-hidden`}>
        <img 
          src={customUrl} 
          alt="Custom Logo" 
          className="w-full h-full object-contain"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }
  return (
    <svg 
      viewBox="0 0 100 100" 
      fill="currentColor" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Compass/Star Background */}
      <g className="text-brand-gold opacity-80">
        <path d="M50 5 L55 45 L95 50 L55 55 L50 95 L45 55 L5 50 L45 45 Z" /> {/* Main 4 points */}
        <path d="M50 50 L20 20 L50 35 L80 20 L65 50 L80 80 L50 65 L20 80 Z" transform="rotate(45 50 50)" className="opacity-60" /> {/* Secondary 4 points */}
        <circle cx="50" cy="50" r="30" fill="none" stroke="currentColor" strokeWidth="0.5" className="opacity-40" />
      </g>
      
      {/* The Phoenix */}
      <g className="text-white drop-shadow-xl">
        {/* Simplified Phoenix Body & Wings to match spirit of the photo */}
        <path d="M50 35 C35 35 25 50 15 65 C25 60 35 55 45 60 C40 70 45 80 50 85 C55 80 60 70 55 60 C65 55 75 60 85 65 C75 50 65 35 50 35 Z" fill="url(#phoenixGradient)" />
        <path d="M50 35 L52 30 L50 25 L48 30 Z" fill="#ff6b00" /> {/* Head */}
      </g>
      
      <defs>
        <linearGradient id="phoenixGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#ffcc00" />
          <stop offset="50%" stopColor="#ff6b00" />
          <stop offset="100%" stopColor="#d90429" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function PremiumLogoText({ className }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <span className="text-[10px] font-black uppercase tracking-[0.5em] text-brand-gold mb-1">Recomeço Jovem</span>
      <span className="text-[8px] font-black text-white/40 tracking-[0.8em]">2026</span>
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>("ambiente");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [customLogoUrl, setCustomLogoUrl] = useState<string | null>(null);
  const [accessCode, setAccessCode] = useState("");
  const [isAuthorized, setIsAuthorized] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToSettings((settings) => {
      if (settings?.logoUrl) {
        setCustomLogoUrl(settings.logoUrl);
      } else {
        setCustomLogoUrl(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 800000) { // Keep under 800KB for Firestore doc limit
        alert("Arquivo muito grande! Escolha um logo menor que 800KB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        try {
          await updateLogo(base64String);
        } catch (error) {
          console.error("Erro ao salvar no Firebase:", error);
          alert("Erro ao salvar! Tente novamente.");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const resetLogo = async () => {
    try {
      await updateLogo("");
    } catch (error) {
      console.error("Erro ao resetar no Firebase:", error);
    }
  };

  const handleAccessCheck = () => {
    if (accessCode === "VITOR2615") {
      setIsAuthorized(true);
    } else {
      alert("Código incorreto!");
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };

  const tabs = [
    { id: "ambiente", label: "Meio Ambiente Escolar", icon: Leaf },
    { id: "esportes", label: "Esportes Escolar", icon: Trophy },
    { id: "social", label: "Vida Social Escolar", icon: Users },
    { id: "editar", label: "Editar Logotipo", icon: Settings },
  ];

  return (
    <div className="min-h-screen selection:bg-brand-orange selection:text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-brand-orange/10">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <div 
            onClick={() => scrollToSection("inicio")}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 bg-brand-orange rounded-xl flex items-center justify-center text-white shadow-lg shadow-brand-orange/20 group-hover:scale-110 transition-transform overflow-hidden">
              <PhoenixLogo className="w-7 h-7" customUrl={customLogoUrl || undefined} />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-black text-brand-dark uppercase tracking-tighter leading-none text-xl">
                RECOMEÇO <span className="text-brand-orange text-xs block tracking-[0.2em] font-bold">JOVEM</span>
              </span>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex gap-8 items-center">
            <button onClick={() => scrollToSection("inicio")} className="text-xs font-black uppercase tracking-widest text-brand-dark/60 hover:text-brand-orange transition-colors">Início</button>
            <button onClick={() => scrollToSection("projetos")} className="text-xs font-black uppercase tracking-widest text-brand-dark/60 hover:text-brand-orange transition-colors">Propostas</button>
            <button className="px-6 py-2 bg-brand-dark text-white rounded-full text-xs font-black uppercase tracking-widest hover:bg-brand-orange transition-all">Saber Mais</button>
          </div>

          {/* Mobile Toggle */}
          <button className="md:hidden text-brand-dark" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-brand-orange/10 overflow-hidden"
            >
              <div className="px-6 py-8 flex flex-col gap-6">
                <button onClick={() => scrollToSection("inicio")} className="text-left font-black uppercase tracking-widest text-brand-dark py-2">Início</button>
                <button onClick={() => scrollToSection("projetos")} className="text-left font-black uppercase tracking-widest text-brand-dark py-2">Propostas</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Seção 1 – Capa (Início) */}
      <section id="inicio" className="relative pt-40 pb-24 md:pt-56 md:pb-48 overflow-hidden bg-brand-dark">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={fadeIn}
            className="flex flex-col items-center text-center max-w-4xl mx-auto"
          >
            {/* Phoenix Logo Principal */}
            <div className="mb-8 relative">
              <PremiumLogoText className="mb-4" />
              <motion.div 
                animate={{ 
                  scale: [1, 1.05, 1],
                  rotate: [-1, 1, -1]
                }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="w-64 h-64 md:w-96 md:h-96 flex items-center justify-center relative"
              >
                <PhoenixLogo 
                  className="w-full h-full drop-shadow-[0_0_50px_rgba(212,175,55,0.3)]" 
                  customUrl={customLogoUrl || undefined}
                />
                <div className="absolute -inset-10 bg-brand-orange/10 blur-[100px] -z-10 rounded-full" />
              </motion.div>
            </div>

            <h1 className="font-display text-5xl md:text-8xl font-black text-white leading-none mb-6 uppercase tracking-tighter">
              PROPOSTAS <span className="fire-text-gradient">RECOMEÇO JOVEM</span>
            </h1>
            
            <div className="flex flex-wrap justify-center gap-x-4 gap-y-2 mb-10 text-xs md:text-sm font-black opacity-40 uppercase tracking-[0.3em]">
              <span>Meio Ambiente Escolar</span>
              <span className="text-brand-orange">•</span>
              <span>Esportes Escolar</span>
              <span className="text-brand-orange">•</span>
              <span>Vida Social Escolar</span>
            </div>

            <p className="text-xl md:text-2xl font-black italic text-brand-yellow mb-12 max-w-2xl bg-white/5 backdrop-blur-sm border border-white/10 px-6 py-4 rounded-2xl shadow-sm">
              “CONHEÇA NOSSAS PROPOSTAS AINDA MELHOR”
            </p>

            <button 
              onClick={() => scrollToSection("projetos")}
              className="group px-12 py-6 bg-brand-dark text-white rounded-full font-black text-sm uppercase tracking-widest flex items-center gap-4 transition-all hover:bg-brand-orange hover:-translate-y-2 shadow-2xl active:scale-95"
            >
              Ver Projetos
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </button>
          </motion.div>
        </div>

        {/* Abstract Background Decor */}
        <div className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-brand-orange/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-yellow/20 rounded-full blur-[100px] pointer-events-none" />
      </section>

      {/* Tabs / Projects Section */}
      <section id="projetos" className="py-24 bg-white border-t border-brand-orange/5">
        <div className="max-w-7xl mx-auto px-6">
          
          {/* Aba Selector */}
          <div className="flex flex-wrap justify-center gap-3 mb-20">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabId)}
                className={`flex items-center gap-3 px-8 py-5 rounded-[24px] font-black transition-all border-2 ${
                  activeTab === tab.id 
                    ? "bg-brand-dark text-white border-brand-dark shadow-2xl scale-110 z-10" 
                    : "bg-brand-light text-brand-dark border-transparent hover:bg-white hover:border-brand-orange/20"
                }`}
              >
                <tab.icon className={`w-6 h-6 ${activeTab === tab.id ? "text-brand-yellow" : "text-brand-orange"}`} />
                <span className="uppercase text-xs tracking-widest">{tab.label}</span>
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {activeTab === "ambiente" && (
              <motion.div
                key="ambiente"
                initial={{ opacity: 0, scale: 0.98, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 1.02, y: -20 }}
                transition={{ duration: 0.4 }}
                className="grid md:grid-cols-2 gap-10"
              >
                {/* Horta + Saúde */}
                <article className="bg-brand-light p-12 rounded-[50px] border border-brand-orange/10 flex flex-col items-start shadow-xl shadow-brand-orange/5 hover:-translate-y-2 transition-all">
                  <div className="w-20 h-20 bg-white rounded-[24px] flex items-center justify-center mb-10 shadow-lg text-brand-orange">
                    <Sprout className="w-10 h-10" />
                  </div>
                  <h3 className="font-display text-4xl font-black text-brand-dark mb-8 tracking-tighter">+Horta +Saúde</h3>
                  <p className="text-brand-dark/70 text-lg leading-relaxed mb-10">
                    O projeto <strong>+Horta +Saúde</strong> tem como foco a criação de uma horta dentro da escola, onde serão plantados alimentos como verduras e legumes. Além do cultivo, o projeto também promove campanhas de conscientização sobre a importância desses alimentos para a saúde, incentivando hábitos alimentares mais saudáveis entre os alunos.
                  </p>
                  <div className="mt-auto flex gap-6 opacity-40">
                    <Heart className="w-6 h-6" />
                    <AppleIcon className="w-6 h-6" />
                    <span className="font-black text-xs uppercase tracking-widest">Saúde & Bem Estar</span>
                  </div>
                </article>

                {/* Eco Ação */}
                <article className="bg-brand-light p-12 rounded-[50px] border border-brand-orange/10 flex flex-col items-start shadow-xl shadow-brand-red/5 hover:-translate-y-2 transition-all">
                  <div className="w-20 h-20 bg-white rounded-[24px] flex items-center justify-center mb-10 shadow-lg text-brand-red">
                    <Globe className="w-10 h-10" />
                  </div>
                  <h3 className="font-display text-4xl font-black text-brand-dark mb-8 tracking-tighter">Eco Ação</h3>
                  <p className="text-brand-dark/70 text-lg leading-relaxed mb-10">
                    O projeto <strong>Eco Ação</strong> é voltado para a preservação do meio ambiente no dia a dia escolar. Ele inclui ações como incentivo à reciclagem, economia de água e energia, redução do uso de plástico e campanhas educativas, buscando tornar a escola mais limpa, organizada e sustentável.
                  </p>
                  <div className="mt-auto flex gap-6 opacity-40">
                    <Recycle className="w-6 h-6" />
                    <ProjectDropletIcon className="w-6 h-6" />
                    <Zap className="w-6 h-6" />
                    <span className="font-black text-xs uppercase tracking-widest">Sustentabilidade</span>
                  </div>
                </article>
              </motion.div>
            )}

            {activeTab === "esportes" && (
              <motion.div
                key="esportes"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="min-h-[400px] flex items-center justify-center text-center p-16 bg-brand-light rounded-[60px] border-4 border-dashed border-brand-orange/20"
              >
                <div>
                  <Trophy className="w-20 h-20 text-brand-yellow mx-auto mb-6 drop-shadow-lg" />
                  <h3 className="text-3xl font-black mb-4 uppercase tracking-tighter">
                    Propostas para Esportes
                  </h3>
                  <p className="text-brand-dark/50 text-xl italic max-w-lg mx-auto font-medium">
                    Preparamos algo incrível para você! Em breve a Chapa RECOMEÇO JOVEM trará todas as novidades. 🚀🔥
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "social" && (
              <motion.div
                key="social"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="min-h-[400px] flex items-center justify-center text-center p-16 bg-brand-light rounded-[60px] border-4 border-dashed border-brand-orange/20"
              >
                <div>
                  <Users className="w-20 h-20 text-brand-orange mx-auto mb-6 drop-shadow-lg" />
                  <h3 className="text-3xl font-black mb-4 uppercase tracking-tighter">
                    Propostas Vida Social
                  </h3>
                  <p className="text-brand-dark/50 text-xl italic max-w-lg mx-auto font-medium">
                    Preparamos algo incrível para você! Em breve a Chapa RECOMEÇO JOVEM trará todas as novidades. 🚀🔥
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === "editar" && (
              <motion.div
                key="editar"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-3xl mx-auto"
              >
                {!isAuthorized ? (
                  <div className="bg-brand-light p-12 rounded-[50px] border border-brand-orange/10 shadow-xl text-center">
                    <div className="w-20 h-20 bg-brand-dark rounded-3xl flex items-center justify-center text-brand-gold mx-auto mb-8 shadow-xl">
                      <Lock className="w-10 h-10" />
                    </div>
                    <h3 className="text-3xl font-black text-brand-dark uppercase tracking-tighter mb-4">Acesso Restrito</h3>
                    <p className="text-brand-dark/60 font-medium mb-10">Digite o código de acesso para editar a identidade visual do site.</p>
                    
                    <div className="max-w-xs mx-auto space-y-4">
                      <div className="relative">
                        <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-orange" />
                        <input 
                          type="password" 
                          value={accessCode}
                          onChange={(e) => setAccessCode(e.target.value)}
                          placeholder="Digite o código..."
                          className="w-full pl-12 pr-4 py-4 bg-white border-2 border-brand-orange/10 rounded-2xl font-black tracking-widest outline-none focus:border-brand-orange transition-all uppercase placeholder:italic placeholder:font-normal placeholder:tracking-normal"
                          onKeyDown={(e) => e.key === "Enter" && handleAccessCheck()}
                        />
                      </div>
                      <button 
                        onClick={handleAccessCheck}
                        className="w-full py-4 bg-brand-dark text-white rounded-2xl font-black uppercase tracking-widest hover:bg-brand-orange transition-all shadow-lg active:scale-95"
                      >
                        Entrar nas Configurações
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-brand-light p-12 rounded-[50px] border border-brand-orange/10 shadow-xl">
                    <div className="flex items-center gap-4 mb-10">
                      <div className="w-16 h-16 bg-brand-dark rounded-2xl flex items-center justify-center text-brand-gold">
                        <ImageIcon className="w-8 h-8" />
                      </div>
                      <div>
                        <h3 className="text-3xl font-black text-brand-dark uppercase tracking-tighter leading-none">Configurações de Logo</h3>
                        <p className="text-brand-dark/40 font-bold uppercase text-[10px] tracking-widest mt-2">Personalize a identidade da sua chapa</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-10">
                      {/* Upload Section */}
                      <div className="space-y-6">
                        <div className="relative group">
                          <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-brand-orange/20 rounded-[30px] bg-white hover:bg-brand-orange/5 transition-all cursor-pointer group-hover:border-brand-orange/40">
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                              <Upload className="w-10 h-10 text-brand-orange mb-4 group-hover:scale-110 transition-transform" />
                              <p className="mb-2 text-sm text-brand-dark font-black uppercase tracking-widest">Enviar Arquivo</p>
                              <p className="text-xs text-brand-dark/40 font-bold">PNG, JPG ou SVG (Max. 800KB)</p>
                            </div>
                            <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                          </label>
                        </div>

                        <button 
                          onClick={resetLogo}
                          className="w-full flex items-center justify-center gap-2 py-4 border-2 border-brand-dark rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-brand-dark hover:text-white transition-all active:scale-95"
                        >
                          <RefreshCcw className="w-4 h-4" />
                          Restaurar Padrão
                        </button>
                      </div>

                      {/* Preview Section */}
                      <div className="flex flex-col items-center justify-center bg-white rounded-[30px] p-8 border border-brand-orange/5">
                        <p className="text-[10px] font-black uppercase tracking-widest text-brand-dark/20 mb-6">Prévia em tempo real</p>
                        <div className="w-32 h-32 md:w-40 md:h-40 bg-brand-dark rounded-3xl flex items-center justify-center text-brand-orange shadow-2xl relative overflow-hidden">
                          <PhoenixLogo className="w-2/3 h-2/3" customUrl={customLogoUrl || undefined} />
                        </div>
                        <p className="mt-6 text-xs text-brand-dark font-black tracking-widest uppercase">Visualização no Header</p>
                      </div>
                    </div>

                    <div className="mt-12 p-6 bg-brand-dark text-white rounded-[30px] flex items-center gap-6">
                      <div className="p-3 bg-brand-gold/20 rounded-xl">
                        <Flame className="w-6 h-6 text-brand-gold" />
                      </div>
                      <p className="text-sm font-medium leading-relaxed italic opacity-80">
                        "As alterações feitas aqui serão visíveis para todos os visitantes do site instantaneamente."
                      </p>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Seção Final (Conclusão) */}
      <section className="py-32 bg-brand-dark text-white relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <div className="inline-block p-6 bg-white/10 rounded-[30px] mb-10 backdrop-blur-md border border-white/5 overflow-hidden">
              <PhoenixLogo className="w-16 h-16 text-brand-yellow" customUrl={customLogoUrl || undefined} />
            </div>
            <h2 className="text-3xl md:text-5xl font-black leading-[1.1] mb-12 tracking-tight uppercase">
              “Dessa forma, os dois projetos se complementam, promovendo ao mesmo tempo a saúde dos alunos e o cuidado com o meio ambiente.”
            </h2>
            <div className="h-1.5 w-32 bg-gradient-to-r from-brand-orange to-brand-yellow mx-auto mb-12 rounded-full shadow-[0_0_25px_rgba(255,107,0,0.8)]" />
            <p className="text-sm font-black uppercase tracking-[0.6em] opacity-30">
              Grêmio estudantil • recomeço jovem
            </p>
          </motion.div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-full h-[1px] bg-white/10" />
        <div className="absolute bottom-0 right-0 p-20 opacity-5">
           <PhoenixLogo className="w-96 h-96" />
        </div>
      </section>

      <footer className="py-16 bg-brand-light border-t border-brand-orange/10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-dark rounded-2xl flex items-center justify-center text-brand-orange overflow-hidden">
              <PhoenixLogo className="w-8 h-8" customUrl={customLogoUrl || undefined} />
            </div>
            <div className="font-display font-black text-brand-dark text-2xl uppercase tracking-tighter flex flex-col leading-tight">
              <span className="text-brand-orange italic">RECOMEÇO</span>
              <span>JOVEM</span>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-10 text-xs font-black uppercase tracking-widest opacity-40">
            <span className="hover:text-brand-orange cursor-pointer transition-colors border-b-2 border-transparent hover:border-brand-orange pb-1">Instagram</span>
            <span className="hover:text-brand-orange cursor-pointer transition-colors border-b-2 border-transparent hover:border-brand-orange pb-1">Facebook</span>
            <span className="hover:text-brand-orange cursor-pointer transition-colors border-b-2 border-transparent hover:border-brand-orange pb-1">Comunidade</span>
          </div>
          
          <p className="text-[11px] font-black opacity-30 uppercase tracking-tighter">
            © {new Date().getFullYear()} – Todo poder ao jovem estudantil
          </p>
        </div>
      </footer>
    </div>
  );
}

function AppleIcon({ className }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 20.94c1.88 0 3.05-1.04 4.14-1.04 1.25 0 2.22.75 4 1.14a1 1 0 0 0 1.25-1.07c-.12-1.3-.87-3.9-1.95-3.9s-1.8 1.4-2.85 1.4-2.1-.47-2.1-1.55c0-.6.12-1.2.35-1.7a9.2 9.2 0 0 0-4.05-4.2c-.85-.45-1.85-.75-2.85-.75-1.85 0-3.1 1.05-4.25 1.05-1.3 0-2.3-.7-3.9-1a1 1 0 0 0-1.15 1.15c.15 1.45.9 3.95 2.1 3.95s1.9-1.3 2.9-1.3 2.15.5 2.15 1.55c0 .7-.15 1.35-.4 1.95a9 9 0 0 0 4.1 4.25c.85.45 1.8.75 2.8.75z" />
      <path d="M10.26 8.5a3.5 3.5 0 0 1 3.48-3.48" />
    </svg>
  );
}

function ProjectDropletIcon({ className }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
    </svg>
  );
}
