/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc, onSnapshot, serverTimestamp } from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

const SETTINGS_COLLECTION = "settings";
const APP_DOC = "app";

export interface AppSettings {
  logoUrl: string | null;
  updatedAt: any;
}

export const getAppSettings = async (): Promise<AppSettings | null> => {
  const docRef = doc(db, SETTINGS_COLLECTION, APP_DOC);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return docSnap.data() as AppSettings;
  }
  return null;
};

export const updateLogo = async (logoUrl: string): Promise<void> => {
  const docRef = doc(db, SETTINGS_COLLECTION, APP_DOC);
  await setDoc(docRef, {
    logoUrl,
    updatedAt: serverTimestamp()
  });
};

export const subscribeToSettings = (callback: (settings: AppSettings | null) => void) => {
  const docRef = doc(db, SETTINGS_COLLECTION, APP_DOC);
  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      callback(docSnap.data() as AppSettings);
    } else {
      callback(null);
    }
  });
};
